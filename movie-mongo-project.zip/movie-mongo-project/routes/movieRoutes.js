const express = require("express");
const router = express.Router();
const Movie = require("../models/Movie");
const multer = require("multer");
const path = require("path");

// 🔹 MULTER CONFIG
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public/uploads");
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({ storage });

// SHOW ALL
router.get("/", async (req, res) => {
  const movies = await Movie.find();
  res.render("list", { movies });
});

// ADD PAGE
router.get("/add", (req, res) => {
  res.render("add");
});

// SAVE MOVIE WITH IMAGE
router.post("/save", upload.single("image"), async (req, res) => {
  const movie = new Movie({
    name: req.body.name,
    category: req.body.category,
    rating: req.body.rating,
    image: req.file.filename   // 👈 image saved
  });

  await movie.save();
  res.redirect("/");
});

// EDIT PAGE
router.get("/edit/:id", async (req, res) => {
  const movie = await Movie.findById(req.params.id);
  res.render("edit", { movie });
});

// UPDATE MOVIE (OPTIONAL IMAGE)
router.post("/update/:id", upload.single("image"), async (req, res) => {
  const updateData = {
    name: req.body.name,
    category: req.body.category,
    rating: req.body.rating
  };

  if (req.file) {
    updateData.image = req.file.filename;
  }

  await Movie.findByIdAndUpdate(req.params.id, updateData);
  res.redirect("/");
});

// DELETE
router.get("/delete/:id", async (req, res) => {
  await Movie.findByIdAndDelete(req.params.id);
  res.redirect("/");
});

module.exports = router;
