const mongoose = require("mongoose");

const DB_URL = "mongodb://127.0.0.1:27017/movieDB";

mongoose.connect(DB_URL)
  .then(() => {
    console.log("MongoDB connected successfully ✅");
  })
  .catch((err) => {
    console.error("MongoDB connection error ❌", err);
  });

module.exports = mongoose;
